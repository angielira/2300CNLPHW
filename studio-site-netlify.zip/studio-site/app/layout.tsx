import type { Metadata } from "next"
import { DM_Serif_Display, Inter } from "next/font/google"
import { SiteProvider } from "@/components/site-provider"
import { site } from "@/lib/site"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const dmSerif = DM_Serif_Display({ subsets: ["latin"], weight: "400", variable: "--font-dm-serif" })

export const metadata: Metadata = {
  title: `Branding & Social Media for Miami Businesses | ${site.name}`,
  description:
    "Brand identity, social media makeovers and done-for-you content for South Florida small businesses, in English or Spanish. Start with a free brand check-up.",
  openGraph: {
    title: `${site.name}: Look as professional as you really are`,
    description: "Branding and social media for South Florida small businesses, in English or Spanish.",
    type: "website",
    locale: "en_US",
    alternateLocale: ["es_US"],
  },
}

// LocalBusiness / ProfessionalService structured data for local search.
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: site.name,
  description: "Branding, social media makeovers and monthly content for small businesses.",
  areaServed: ["Miami-Dade County, FL", "Broward County, FL", "Palm Beach County, FL"],
  availableLanguage: ["English", "Spanish"],
  priceRange: "$500-$2000",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${dmSerif.variable} font-sans antialiased`}>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <SiteProvider>{children}</SiteProvider>
      </body>
    </html>
  )
}
