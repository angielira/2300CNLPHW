import { Navbar } from "@/components/sections/navbar"
import { Hero } from "@/components/sections/hero"
import { Problem } from "@/components/sections/problem"
import { Solution } from "@/components/sections/solution"
import { Services } from "@/components/sections/services"
import { CostCalculator } from "@/components/sections/cost-calculator"
import { SocialProof } from "@/components/sections/social-proof"
import { Pricing } from "@/components/sections/pricing"
import { Platforms } from "@/components/sections/platforms"
import { VideoSection } from "@/components/sections/video"
import { FinalCta } from "@/components/sections/final-cta"
import { Footer } from "@/components/sections/footer"

// Section order follows the Landing Page PRD: Problem → Agitate → Solve, then proof and pricing.
export default function Page() {
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[2000] focus:rounded-full focus:bg-background focus:px-4 focus:py-2">
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <Problem />
        <Solution />
        <Services />
        <CostCalculator />
        <SocialProof />
        <Pricing />
        <Platforms />
        <VideoSection />
        <FinalCta />
      </main>
      <Footer />
    </>
  )
}
