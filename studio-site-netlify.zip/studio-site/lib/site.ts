// Studio settings — replace the placeholders before publishing.
export const site = {
  name: "[Studio Name]",
  /** WhatsApp number in international format, digits only (e.g. 13055551234). */
  whatsapp: "13055550000",
  email: "hello@example.com",
  /** Optional form endpoint (Formspree, Web3Forms, your own API route). Leave empty to use the demo handler. */
  formEndpoint: process.env.NEXT_PUBLIC_FORM_ENDPOINT ?? "",
}

export const whatsappLink = (message: string) =>
  `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(message)}`
