// Shared button and layout classes, from the PRD's component styles.

const base =
  "inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-7 text-base font-semibold transition duration-150 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-lagoon focus-visible:ring-offset-2 focus-visible:ring-offset-background motion-reduce:transition-none"

export const btn = {
  primary: `${base} bg-gradient-to-r from-brand-hibiscus to-brand-violet text-white shadow-lg shadow-brand-violet/25 hover:-translate-y-0.5 hover:shadow-xl`,
  secondary: `${base} border-2 border-foreground/80 text-foreground hover:bg-foreground/5`,
  onGradient: `${base} bg-white text-brand-ink shadow-lg hover:-translate-y-0.5 hover:shadow-xl`,
  outlineOnGradient: `${base} border-2 border-white text-white hover:bg-white/10`,
}

export const container = "mx-auto w-full max-w-[1200px] px-4 sm:px-6"
export const section = "py-[60px] md:py-20 lg:py-[120px]"
export const eyebrow = "text-sm font-semibold uppercase tracking-wider text-brand-violet dark:text-brand-sand"
export const h2 = "font-serif text-[30px] leading-[1.2] md:text-[40px]"
