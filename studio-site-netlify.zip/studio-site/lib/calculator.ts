export interface CalculatorInputs {
  hoursPerWeek: number
  hourlyValue: number
  customerValue: number
  newCustomersPerMonth: number
}

/** Share of social-media time the studio takes off the owner's plate. */
export const TIME_SAVED_SHARE = 0.8
/** Illustrative lift in new customers from a consistent, professional brand. Not a guarantee. */
export const CUSTOMER_LIFT = 0.1

const clamp = (n: number, min: number, max: number) =>
  Number.isFinite(n) ? Math.min(Math.max(n, min), max) : min

export function calculateCost(inputs: CalculatorInputs) {
  const hours = clamp(inputs.hoursPerWeek, 0, 20)
  const hourly = clamp(inputs.hourlyValue, 0, 1000)
  const customerValue = clamp(inputs.customerValue, 0, 100000)
  const customers = clamp(inputs.newCustomersPerMonth, 0, 10000)

  const hoursBack = Math.round(hours * TIME_SAVED_SHARE * 52)
  const timeValue = Math.round(hoursBack * hourly)
  const revenueLift = Math.round(customers * 12 * CUSTOMER_LIFT * customerValue)

  return { hoursBack, timeValue, revenueLift, total: timeValue + revenueLift }
}

export const formatUSD = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n)
