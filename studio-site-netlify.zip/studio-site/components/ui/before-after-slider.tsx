"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

interface BeforeAfterSliderProps {
  before: React.ReactNode
  after: React.ReactNode
  beforeLabel: string
  afterLabel: string
  /** Accessible label for the range control. */
  label: string
  className?: string
}

/**
 * Draggable before/after comparison. A transparent native range input sits on top,
 * so mouse, touch and keyboard (arrow keys) all work without custom handlers.
 */
export function BeforeAfterSlider({ before, after, beforeLabel, afterLabel, label, className }: BeforeAfterSliderProps) {
  const [position, setPosition] = useState(50)

  return (
    <div className={cn("relative aspect-[4/5] w-full select-none overflow-hidden rounded-3xl border border-border shadow-xl sm:aspect-[4/3]", className)}>
      {/* After (full) */}
      <div className="absolute inset-0">{after}</div>

      {/* Before (clipped from the right) */}
      <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}>
        {before}
      </div>

      {/* Labels */}
      <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-black/70 px-3 py-1 text-xs font-semibold text-white">{beforeLabel}</span>
      <span className="pointer-events-none absolute right-3 top-3 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-brand-ink">{afterLabel}</span>

      {/* Divider + handle */}
      <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow-[0_0_0_1px_rgba(0,0,0,0.15)]" style={{ left: `${position}%` }}>
        <div className="absolute left-1/2 top-1/2 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white text-brand-ink shadow-lg">
          <span aria-hidden="true" className="text-sm font-bold">‹ ›</span>
        </div>
      </div>

      <input
        type="range"
        min={0}
        max={100}
        value={position}
        onChange={(e) => setPosition(Number(e.target.value))}
        aria-label={label}
        className="peer absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
      />
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 rounded-3xl ring-brand-lagoon ring-offset-2 peer-focus-visible:ring-2" />
    </div>
  )
}
