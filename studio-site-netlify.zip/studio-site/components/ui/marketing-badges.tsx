"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

export interface MarketingBadge {
  id: string
  label: string
  /** Tailwind gradient classes, e.g. "from-brand-orange to-brand-mango" */
  color: string
  /** Text color class with enough contrast against the gradient */
  textColor?: string
  size: "sm" | "md" | "lg"
  rotation: number
  zIndex: number
  offsetX: number
  offsetY: number
}

// Defaults use the studio's "South Florida Sunset" palette and its services.
const defaultBadges: MarketingBadge[] = [
  { id: "branding", label: "branding", color: "from-brand-sand to-brand-mango", size: "lg", rotation: -3, zIndex: 1, offsetX: -20, offsetY: -60 },
  { id: "logo", label: "logo design", color: "from-brand-mango to-brand-orange", size: "sm", rotation: 2, zIndex: 2, offsetX: 60, offsetY: -35 },
  { id: "social-media", label: "social media", color: "from-brand-guava to-brand-hibiscus", textColor: "text-white", size: "lg", rotation: -2, zIndex: 3, offsetX: -30, offsetY: -15 },
  { id: "content", label: "monthly content", color: "from-brand-hibiscus to-brand-violet", textColor: "text-white", size: "lg", rotation: 0, zIndex: 4, offsetX: 0, offsetY: 25 },
  { id: "reels", label: "Reels", color: "from-brand-lagoon to-brand-atlantic", size: "md", rotation: 3, zIndex: 5, offsetX: -15, offsetY: 65 },
  { id: "bilingual", label: "EN / ES", color: "from-brand-sand to-brand-lagoon", size: "sm", rotation: -1, zIndex: 6, offsetX: 50, offsetY: 90 },
]

const sizeClasses = {
  sm: "px-6 py-2.5 text-base",
  md: "px-8 py-3 text-lg",
  lg: "px-10 py-3.5 text-xl",
}

interface MarketingBadgesProps {
  badges?: MarketingBadge[]
  className?: string
  onSelect?: (id: string | null) => void
}

export function MarketingBadges({ badges = defaultBadges, className, onSelect }: MarketingBadgesProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const [clickedId, setClickedId] = useState<string | null>(null)

  const handleClick = (id: string) => {
    const next = clickedId === id ? null : id
    setClickedId(next)
    onSelect?.(next)
  }

  return (
    <div className={cn("relative flex h-[400px] w-full items-center justify-center", className)}>
      {badges.map((badge) => {
        const isHovered = hoveredId === badge.id
        const isClicked = clickedId === badge.id
        const isOtherHovered = hoveredId !== null && hoveredId !== badge.id

        return (
          <button
            type="button"
            key={badge.id}
            aria-pressed={isClicked}
            className={cn(
              "absolute cursor-pointer select-none rounded-full font-semibold transition-all duration-500 ease-out motion-reduce:transition-none",
              "bg-gradient-to-b shadow-lg hover:shadow-2xl",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-lagoon focus-visible:ring-offset-2",
              badge.color,
              sizeClasses[badge.size],
            )}
            style={{
              transform: `translate(${badge.offsetX}px, ${badge.offsetY}px) rotate(${isHovered ? 0 : badge.rotation}deg) scale(${isClicked ? 1.15 : isHovered ? 1.08 : isOtherHovered ? 0.95 : 1}) translateY(${isHovered ? -8 : 0}px)`,
              zIndex: isHovered || isClicked ? 100 : badge.zIndex,
              boxShadow: isHovered
                ? "0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 12px 24px -8px rgba(0, 0, 0, 0.15), inset 0 2px 4px rgba(255, 255, 255, 0.3)"
                : isClicked
                  ? "0 30px 60px -15px rgba(0, 0, 0, 0.3), inset 0 2px 4px rgba(255, 255, 255, 0.4)"
                  : "0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 4px 10px -2px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.2)",
            }}
            onMouseEnter={() => setHoveredId(badge.id)}
            onMouseLeave={() => setHoveredId(null)}
            onFocus={() => setHoveredId(badge.id)}
            onBlur={() => setHoveredId(null)}
            onClick={() => handleClick(badge.id)}
          >
            <span
              className={cn(
                "relative block transition-transform duration-300",
                badge.textColor ?? "text-brand-ink",
              )}
              style={{ transform: isHovered ? "translateY(-1px)" : "translateY(0)" }}
            >
              {badge.label}
            </span>
            {/* Inner highlight effect */}
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 rounded-full opacity-50"
              style={{ background: "linear-gradient(180deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0) 50%)" }}
            />
          </button>
        )
      })}
    </div>
  )
}
