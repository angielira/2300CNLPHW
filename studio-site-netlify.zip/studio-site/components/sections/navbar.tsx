"use client"

import { useEffect, useState } from "react"
import { Globe, Menu, X } from "lucide-react"
import { useSite } from "@/components/site-provider"
import { site } from "@/lib/site"
import { btn } from "@/lib/styles"
import { cn } from "@/lib/utils"

export function Navbar() {
  const { t, toggleLang, openForm } = useSite()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  // Close the drawer with Escape and lock page scroll while it's open.
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false)
    document.addEventListener("keydown", onKey)
    document.body.style.overflow = "hidden"
    return () => {
      document.removeEventListener("keydown", onKey)
      document.body.style.overflow = ""
    }
  }, [open])

  const links = [
    { href: "#services", label: t.nav.services },
    { href: "#how", label: t.nav.how },
    { href: "#pricing", label: t.nav.pricing },
    { href: "#faq", label: t.nav.faq },
  ]

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-[1000] transition-all duration-300",
        scrolled ? "border-b border-border bg-background/85 shadow-sm backdrop-blur-md" : "bg-transparent",
      )}
    >
      <nav aria-label="Main" className="mx-auto flex h-[60px] max-w-[1200px] items-center justify-between gap-4 px-4 sm:px-6 lg:h-[72px]">
        <a href="#top" className="flex items-center gap-2 font-serif text-xl">
          <span aria-hidden="true" className="size-8 rounded-full bg-brand-gradient" />
          {site.name}
        </a>

        <ul className="hidden items-center gap-8 lg:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="text-sm font-medium text-muted-foreground transition hover:text-foreground">
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleLang}
            className="inline-flex min-h-11 items-center gap-1.5 rounded-full px-3 text-sm font-medium hover:bg-foreground/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-lagoon"
          >
            <Globe className="size-4" aria-hidden="true" />
            {t.nav.language}
          </button>
          <button type="button" onClick={() => openForm("nav")} className={cn(btn.primary, "hidden min-h-11 px-5 text-sm sm:inline-flex")}>
            {t.nav.cta}
          </button>
          <button
            type="button"
            onClick={() => setOpen(true)}
            aria-label={t.nav.menu}
            aria-expanded={open}
            aria-controls="mobile-menu"
            className="inline-flex size-11 items-center justify-center rounded-full hover:bg-foreground/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-lagoon lg:hidden"
          >
            <Menu className="size-6" aria-hidden="true" />
          </button>
        </div>
      </nav>

      {/* Mobile slide-out drawer */}
      <div className={cn("fixed inset-0 z-[1001] lg:hidden", open ? "pointer-events-auto" : "pointer-events-none")} aria-hidden={!open}>
        <div
          onClick={() => setOpen(false)}
          className={cn("absolute inset-0 bg-black/40 transition-opacity", open ? "opacity-100" : "opacity-0")}
        />
        <div
          id="mobile-menu"
          role="dialog"
          aria-modal="true"
          aria-label={t.nav.menu}
          className={cn(
            "absolute right-0 top-0 flex h-full w-[85%] max-w-sm flex-col gap-2 bg-background p-6 shadow-2xl transition-transform duration-300",
            open ? "translate-x-0" : "translate-x-full",
          )}
        >
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label={t.nav.close}
            tabIndex={open ? 0 : -1}
            className="mb-4 inline-flex size-11 items-center justify-center self-end rounded-full hover:bg-foreground/5"
          >
            <X className="size-6" aria-hidden="true" />
          </button>
          {links.map((l) => (
            <a key={l.href} href={l.href} tabIndex={open ? 0 : -1} onClick={() => setOpen(false)} className="rounded-xl px-3 py-3 text-lg font-medium hover:bg-muted">
              {l.label}
            </a>
          ))}
          <button
            type="button"
            tabIndex={open ? 0 : -1}
            onClick={() => {
              setOpen(false)
              openForm("mobile_menu")
            }}
            className={cn(btn.primary, "mt-4 w-full")}
          >
            {t.nav.cta}
          </button>
        </div>
      </div>
    </header>
  )
}
