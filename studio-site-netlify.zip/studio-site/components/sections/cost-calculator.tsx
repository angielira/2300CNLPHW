"use client"

import { useId, useState } from "react"
import { Reveal } from "@/components/ui/reveal"
import { track, useSite } from "@/components/site-provider"
import { calculateCost, formatUSD, type CalculatorInputs } from "@/lib/calculator"
import { btn, container, h2, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

function Field({ label, children, value }: { label: string; children: (id: string) => React.ReactNode; value?: string }) {
  const id = useId()
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <label htmlFor={id} className="text-sm font-medium">{label}</label>
        {value && <span className="text-sm font-semibold text-brand-violet dark:text-brand-sand">{value}</span>}
      </div>
      {children(id)}
    </div>
  )
}

const inputClass =
  "h-12 w-full rounded-[10px] border border-border bg-background px-4 text-base focus:border-brand-lagoon focus:outline-none focus:ring-2 focus:ring-brand-lagoon/40"

export function CostCalculator() {
  const { t, openForm } = useSite()
  const [inputs, setInputs] = useState<CalculatorInputs>({ hoursPerWeek: 5, hourlyValue: 40, customerValue: 60, newCustomersPerMonth: 20 })
  const [touched, setTouched] = useState(false)
  const result = calculateCost(inputs)

  const update = (key: keyof CalculatorInputs, raw: string) => {
    const n = raw === "" ? 0 : Number(raw)
    setInputs((prev) => ({ ...prev, [key]: Number.isFinite(n) && n >= 0 ? n : 0 }))
    if (!touched) {
      setTouched(true)
      track("calculator_use")
    }
  }

  const max = Math.max(result.timeValue, result.revenueLift, 1)

  return (
    <section aria-labelledby="calc-title" className={cn(section, "bg-muted")}>
      <div className={cn(container, "max-w-[900px]")}>
        <Reveal className="text-center">
          <h2 id="calc-title" className={h2}>{t.calc.h2}</h2>
          <p className="mt-3 text-lg text-muted-foreground">{t.calc.sub}</p>
        </Reveal>

        <Reveal delay={100} className="mt-10 grid gap-8 rounded-3xl border border-border bg-card p-6 shadow-lg md:grid-cols-2 md:p-10">
          <div className="space-y-6">
            <Field label={t.calc.hours} value={`${inputs.hoursPerWeek}h`}>
              {(id) => (
                <input id={id} type="range" min={0} max={20} value={inputs.hoursPerWeek} onChange={(e) => update("hoursPerWeek", e.target.value)} className="h-12 w-full accent-[var(--color-brand-hibiscus)]" />
              )}
            </Field>
            <Field label={t.calc.hourly}>
              {(id) => <input id={id} type="number" inputMode="numeric" min={0} value={inputs.hourlyValue} onChange={(e) => update("hourlyValue", e.target.value)} className={inputClass} />}
            </Field>
            <Field label={t.calc.customerValue}>
              {(id) => <input id={id} type="number" inputMode="numeric" min={0} value={inputs.customerValue} onChange={(e) => update("customerValue", e.target.value)} className={inputClass} />}
            </Field>
            <Field label={t.calc.newCustomers}>
              {(id) => <input id={id} type="number" inputMode="numeric" min={0} value={inputs.newCustomersPerMonth} onChange={(e) => update("newCustomersPerMonth", e.target.value)} className={inputClass} />}
            </Field>
          </div>

          <div className="flex flex-col justify-between gap-6 rounded-2xl bg-muted p-6" aria-live="polite">
            <div>
              <p className="text-sm font-medium text-muted-foreground">{t.calc.result}</p>
              <p key={result.total} className="mt-1 text-5xl font-bold text-brand-hibiscus animate-in fade-in-0 zoom-in-95 duration-300 md:text-6xl">
                {formatUSD(result.total)}
              </p>
              <p className="mt-2 text-sm text-muted-foreground">{result.hoursBack} {t.calc.hoursBack}</p>
            </div>

            <div className="space-y-4">
              {[
                { label: t.calc.timeLabel, value: result.timeValue, color: "bg-brand-lagoon" },
                { label: t.calc.revenueLabel, value: result.revenueLift, color: "bg-brand-hibiscus" },
              ].map((bar) => (
                <div key={bar.label}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span>{bar.label}</span>
                    <span className="font-semibold">{formatUSD(bar.value)}</span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-background">
                    <div className={cn("h-full rounded-full transition-all duration-500", bar.color)} style={{ width: `${(bar.value / max) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>

            <button type="button" onClick={() => openForm("calculator")} className={btn.primary}>{t.calc.cta}</button>
            <p className="text-xs leading-relaxed text-muted-foreground">{t.calc.note}</p>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
