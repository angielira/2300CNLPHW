"use client"

import { Play } from "lucide-react"
import { Reveal } from "@/components/ui/reveal"
import { useSite } from "@/components/site-provider"
import { container, h2, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

/** Set this to your video's embed URL (YouTube, Vimeo, or an MP4 path) when it's ready. */
const VIDEO_SRC = ""

export function VideoSection() {
  const { t, openForm } = useSite()

  return (
    <section aria-labelledby="video-title" className={cn(section, "bg-muted")}>
      <div className={cn(container, "max-w-[900px] text-center")}>
        <Reveal>
          <h2 id="video-title" className={h2}>{t.video.h2}</h2>
          <p className="mt-3 text-lg text-muted-foreground">{t.video.sub}</p>
        </Reveal>
        <Reveal delay={100} className="mt-10">
          <div className="relative aspect-video overflow-hidden rounded-3xl border border-border shadow-xl">
            {VIDEO_SRC ? (
              <iframe src={VIDEO_SRC} title={t.video.h2} loading="lazy" allow="encrypted-media; picture-in-picture" allowFullScreen className="absolute inset-0 h-full w-full" />
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-brand-gradient text-white">
                <span className="flex size-20 items-center justify-center rounded-full bg-white/25 backdrop-blur">
                  <Play className="size-9 fill-white" aria-hidden="true" />
                </span>
                <span className="rounded-full bg-black/40 px-4 py-1.5 text-sm font-semibold">{t.video.placeholder}</span>
              </div>
            )}
          </div>
        </Reveal>
        <button type="button" onClick={() => openForm("video")} className="mt-8 font-semibold text-brand-violet dark:text-brand-sand underline-offset-4 hover:underline">
          {t.video.cta}
        </button>
      </div>
    </section>
  )
}
