"use client"

import { Camera, MapPin, MessageCircle, Music2, ShieldCheck, Users } from "lucide-react"
import { Reveal } from "@/components/ui/reveal"
import { useSite } from "@/components/site-provider"
import { container, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

// Generic lucide icons stand in for platform logos (no trademarked artwork needed).
const platformIcons = [Camera, Users, Music2, MapPin, MessageCircle]

export function Platforms() {
  const { t } = useSite()

  return (
    <section aria-label={`${t.platforms.h2Where} · ${t.platforms.h2Own}`} className={section}>
      <div className={cn(container, "grid gap-8 lg:grid-cols-2")}>
        <Reveal className="rounded-3xl border border-border bg-card p-8 md:p-10">
          <h2 className="font-serif text-3xl">{t.platforms.h2Where}</h2>
          <p className="mt-3 text-muted-foreground">{t.platforms.whereSub}</p>
          <ul className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3">
            {t.platforms.list.map((name, i) => {
              const Icon = platformIcons[i]
              return (
                <li key={name} className="flex flex-col items-center gap-2 rounded-2xl bg-muted p-4 text-center text-sm font-medium">
                  <Icon className="size-7 text-brand-hibiscus" aria-hidden="true" />
                  {name}
                </li>
              )
            })}
          </ul>
        </Reveal>

        <Reveal delay={100} className="rounded-3xl bg-brand-ink p-8 text-white md:p-10">
          <ShieldCheck className="size-10 text-brand-lagoon" aria-hidden="true" />
          <h2 className="mt-4 font-serif text-3xl">{t.platforms.h2Own}</h2>
          <ul className="mt-6 space-y-4">
            {t.platforms.own.map((item) => (
              <li key={item} className="flex gap-3 text-lg">
                <span aria-hidden="true" className="mt-2.5 size-2 shrink-0 rounded-full bg-brand-sand" />
                {item}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  )
}
