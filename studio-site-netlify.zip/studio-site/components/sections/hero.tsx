"use client"

import { MapPin, Store } from "lucide-react"
import { MarketingBadges, type MarketingBadge } from "@/components/ui/marketing-badges"
import { useSite } from "@/components/site-provider"
import { btn, container } from "@/lib/styles"
import { cn } from "@/lib/utils"

export function Hero() {
  const { t, lang, openForm } = useSite()

  const labels =
    lang === "es"
      ? ["marca", "diseño de logo", "redes sociales", "contenido mensual", "Reels", "EN / ES"]
      : ["branding", "logo design", "social media", "monthly content", "Reels", "EN / ES"]

  const badges: MarketingBadge[] = [
    { id: "branding", label: labels[0], color: "from-brand-sand to-brand-mango", size: "lg", rotation: -3, zIndex: 1, offsetX: -20, offsetY: -60 },
    { id: "logo", label: labels[1], color: "from-brand-mango to-brand-orange", size: "sm", rotation: 2, zIndex: 2, offsetX: 60, offsetY: -35 },
    { id: "social", label: labels[2], color: "from-brand-guava to-brand-hibiscus", textColor: "text-white", size: "lg", rotation: -2, zIndex: 3, offsetX: -30, offsetY: -15 },
    { id: "content", label: labels[3], color: "from-brand-hibiscus to-brand-violet", textColor: "text-white", size: "lg", rotation: 0, zIndex: 4, offsetX: 0, offsetY: 25 },
    { id: "reels", label: labels[4], color: "from-brand-lagoon to-brand-atlantic", size: "md", rotation: 3, zIndex: 5, offsetX: -15, offsetY: 65 },
    { id: "bilingual", label: labels[5], color: "from-brand-sand to-brand-lagoon", size: "sm", rotation: -1, zIndex: 6, offsetX: 50, offsetY: 90 },
  ]

  return (
    <section id="top" className="relative flex min-h-[90vh] items-center overflow-hidden pb-16 pt-[110px] lg:pt-[120px]">
      {/* Soft brand glow background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-40 -top-40 size-[520px] rounded-full bg-brand-orange/15 blur-3xl" />
        <div className="absolute -right-40 top-20 size-[520px] rounded-full bg-brand-violet/15 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 size-[400px] rounded-full bg-brand-lagoon/10 blur-3xl" />
      </div>

      <div className={cn(container, "grid items-center gap-10 lg:grid-cols-[3fr_2fr]")}>
        <div className="space-y-6">
          <p className="inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-4 py-1.5 text-sm font-medium backdrop-blur">
            <MapPin className="size-4 text-brand-orange" aria-hidden="true" />
            {t.hero.badge}
          </p>
          <h1 className="font-serif text-[40px] leading-[1.1] md:text-[60px]">
            {t.hero.h1a}{" "}
            <span className="bg-brand-gradient bg-clip-text text-transparent">{t.hero.h1b}</span>
          </h1>
          <p className="max-w-xl text-[17px] leading-relaxed text-muted-foreground md:text-lg">{t.hero.sub}</p>

          <div className="flex flex-col gap-3 sm:flex-row">
            <button type="button" onClick={() => openForm("hero")} className={btn.primary} data-event="cta_hero_primary">
              {t.hero.cta1}
            </button>
            <a href="#before-after" className={btn.secondary} data-event="cta_hero_secondary">
              {t.hero.cta2}
            </a>
          </div>
          <p className="text-sm text-muted-foreground">{t.hero.micro.join(" • ")}</p>

          {/* Trust row — replace placeholders with real client logos (with permission) */}
          <div className="pt-4">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{t.hero.trust}</p>
            <ul className="flex flex-wrap gap-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <li
                  key={i}
                  className="flex h-10 items-center gap-1.5 rounded-lg border border-dashed border-border px-3 text-xs text-muted-foreground grayscale transition hover:grayscale-0"
                >
                  <Store className="size-4 text-brand-hibiscus" aria-hidden="true" />
                  {t.hero.logoPlaceholder}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="relative">
          <MarketingBadges badges={badges} />
        </div>
      </div>
    </section>
  )
}
