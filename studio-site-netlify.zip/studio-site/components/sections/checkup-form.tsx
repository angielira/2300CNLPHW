"use client"

import { useEffect, useRef, useState } from "react"
import { CheckCircle2, Loader2, MessageCircle, X } from "lucide-react"
import { track, useSite } from "@/components/site-provider"
import { site, whatsappLink } from "@/lib/site"
import { btn } from "@/lib/styles"
import { cn } from "@/lib/utils"

type Status = "idle" | "sending" | "success" | "error"
type Errors = Partial<Record<"name" | "business" | "type" | "phone" | "email" | "consent", string>>

const fieldClass =
  "h-12 w-full rounded-[10px] border bg-background px-4 text-base focus:outline-none focus:ring-2 focus:ring-brand-lagoon/40 focus:border-brand-lagoon"

export function CheckupForm({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t, lang } = useSite()
  const f = t.form
  const dialogRef = useRef<HTMLDivElement>(null)
  const [status, setStatus] = useState<Status>("idle")
  const [errors, setErrors] = useState<Errors>({})
  const [started, setStarted] = useState(false)

  // Escape to close, lock scroll, and move focus into the dialog.
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose()
    document.addEventListener("keydown", onKey)
    document.body.style.overflow = "hidden"
    const timer = window.setTimeout(() => dialogRef.current?.querySelector<HTMLElement>("input, button")?.focus(), 50)
    return () => {
      document.removeEventListener("keydown", onKey)
      document.body.style.overflow = ""
      window.clearTimeout(timer)
    }
  }, [open, onClose])

  useEffect(() => {
    if (!open) {
      setStatus("idle")
      setErrors({})
    }
  }, [open])

  if (!open) return null

  const validate = (data: FormData): Errors => {
    const e: Errors = {}
    const get = (k: string) => String(data.get(k) ?? "").trim()
    if (!get("name")) e.name = f.required
    if (!get("business")) e.business = f.required
    if (!get("type")) e.type = f.required
    const phone = get("phone").replace(/[^\d+]/g, "")
    if (!phone) e.phone = f.required
    else if (phone.replace(/\D/g, "").length < 10) e.phone = f.invalidPhone
    const email = get("email")
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = f.invalidEmail
    if (!data.get("consent")) e.consent = f.consentRequired
    return e
  }

  const onSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const found = validate(data)
    setErrors(found)
    if (Object.keys(found).length) {
      const first = Object.keys(found)[0]
      event.currentTarget.querySelector<HTMLElement>(`[name="${first}"]`)?.focus()
      return
    }

    setStatus("sending")
    const payload = {
      ...Object.fromEntries(data.entries()),
      frustrations: data.getAll("frustrations"),
      pageLanguage: lang,
    }

    try {
      if (site.formEndpoint) {
        const res = await fetch(site.formEndpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify(payload),
        })
        if (!res.ok) throw new Error(`Form error ${res.status}`)
      } else {
        // Demo handler: no endpoint configured yet. Set NEXT_PUBLIC_FORM_ENDPOINT to receive real submissions.
        await new Promise((r) => setTimeout(r, 900))
        console.info("Check-up request (demo, not sent):", payload)
      }
      setStatus("success")
      track("form_submit", { form: "brand_checkup" })
    } catch {
      setStatus("error")
    }
  }

  const err = (key: keyof Errors) =>
    errors[key] ? (
      <p id={`${key}-error`} className="mt-1.5 text-sm text-error">
        {errors[key]}
      </p>
    ) : null

  const aria = (key: keyof Errors) => ({
    "aria-invalid": Boolean(errors[key]) || undefined,
    "aria-describedby": errors[key] ? `${key}-error` : undefined,
  })

  return (
    <div className="fixed inset-0 z-[1100] flex items-end justify-center sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-black/50 animate-in fade-in-0" onClick={onClose} aria-hidden="true" />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="checkup-title"
        className="relative flex max-h-[100dvh] w-full flex-col overflow-y-auto bg-background p-6 shadow-2xl animate-in slide-in-from-bottom-4 sm:max-h-[90vh] sm:max-w-lg sm:rounded-3xl sm:p-8"
      >
        <button type="button" onClick={onClose} aria-label={f.close} className="absolute right-4 top-4 flex size-11 items-center justify-center rounded-full hover:bg-muted">
          <X className="size-5" aria-hidden="true" />
        </button>

        {status === "success" ? (
          <div className="py-10 text-center" role="status">
            <CheckCircle2 className="mx-auto size-16 text-success animate-in zoom-in-50 duration-500" aria-hidden="true" />
            <h2 id="checkup-title" className="mt-5 font-serif text-3xl">{f.successTitle}</h2>
            <p className="mt-3 text-muted-foreground">{f.successBody}</p>
            <button type="button" onClick={onClose} className={cn(btn.primary, "mt-8")}>{f.close}</button>
          </div>
        ) : (
          <>
            <h2 id="checkup-title" className="pr-10 font-serif text-3xl">{f.title}</h2>
            <p className="mt-2 text-muted-foreground">{f.sub}</p>

            <form noValidate onSubmit={onSubmit} onChange={() => !started && (setStarted(true), track("form_start", { form: "brand_checkup" }))} className="mt-6 space-y-4">
              <div>
                <label htmlFor="cf-name" className="mb-1.5 block text-sm font-medium">{f.name}</label>
                <input id="cf-name" name="name" autoComplete="name" className={cn(fieldClass, errors.name ? "border-error" : "border-border")} {...aria("name")} />
                {err("name")}
              </div>
              <div>
                <label htmlFor="cf-business" className="mb-1.5 block text-sm font-medium">{f.business}</label>
                <input id="cf-business" name="business" autoComplete="organization" className={cn(fieldClass, errors.business ? "border-error" : "border-border")} {...aria("business")} />
                {err("business")}
              </div>
              <div>
                <label htmlFor="cf-type" className="mb-1.5 block text-sm font-medium">{f.type}</label>
                <select id="cf-type" name="type" defaultValue="" className={cn(fieldClass, errors.type ? "border-error" : "border-border")} {...aria("type")}>
                  <option value="" disabled>{f.typePlaceholder}</option>
                  {f.typeOptions.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
                {err("type")}
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="cf-phone" className="mb-1.5 block text-sm font-medium">{f.phone}</label>
                  <input id="cf-phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" className={cn(fieldClass, errors.phone ? "border-error" : "border-border")} {...aria("phone")} />
                  {err("phone")}
                </div>
                <div>
                  <label htmlFor="cf-instagram" className="mb-1.5 block text-sm font-medium">{f.instagram}</label>
                  <input id="cf-instagram" name="instagram" placeholder="@" autoCapitalize="none" className={cn(fieldClass, "border-border")} />
                </div>
              </div>
              <div>
                <label htmlFor="cf-email" className="mb-1.5 block text-sm font-medium">{f.email}</label>
                <input id="cf-email" name="email" type="email" autoComplete="email" className={cn(fieldClass, errors.email ? "border-error" : "border-border")} {...aria("email")} />
                {err("email")}
              </div>

              <fieldset>
                <legend className="mb-2 text-sm font-medium">{f.language}</legend>
                <div className="flex gap-3">
                  {[
                    ["en", "English"],
                    ["es", "Español"],
                  ].map(([value, label]) => (
                    <label key={value} className="flex min-h-11 flex-1 cursor-pointer items-center gap-2 rounded-[10px] border border-border px-4 has-[:checked]:border-brand-hibiscus has-[:checked]:bg-brand-hibiscus/10">
                      <input type="radio" name="preferredLanguage" value={value} defaultChecked={value === lang} className="accent-[var(--color-brand-hibiscus)]" />
                      {label}
                    </label>
                  ))}
                </div>
              </fieldset>

              <fieldset>
                <legend className="mb-2 text-sm font-medium">{f.frustrations}</legend>
                <div className="grid gap-2 sm:grid-cols-2">
                  {f.frustrationOptions.map((o) => (
                    <label key={o} className="flex min-h-11 cursor-pointer items-center gap-2 rounded-[10px] border border-border px-3 text-sm has-[:checked]:border-brand-lagoon has-[:checked]:bg-brand-lagoon/10">
                      <input type="checkbox" name="frustrations" value={o} className="size-4 accent-[var(--color-brand-lagoon)]" />
                      {o}
                    </label>
                  ))}
                </div>
              </fieldset>

              <div>
                <label className="flex items-start gap-3 text-sm">
                  <input type="checkbox" name="consent" value="yes" className="mt-0.5 size-5 accent-[var(--color-brand-hibiscus)]" {...aria("consent")} />
                  <span>
                    {f.consent}{" "}
                    <a href="/privacy" target="_blank" className="underline underline-offset-2">{f.privacy}</a>
                  </span>
                </label>
                {err("consent")}
              </div>

              {status === "error" && (
                <p role="alert" className="rounded-xl bg-error/10 p-3 text-sm text-error">{f.error}</p>
              )}

              <button type="submit" disabled={status === "sending"} className={cn(btn.primary, "w-full disabled:opacity-70")}>
                {status === "sending" ? (
                  <>
                    <Loader2 className="size-5 animate-spin" aria-hidden="true" />
                    {f.sending}
                  </>
                ) : (
                  f.submit
                )}
              </button>
              <a
                href={whatsappLink(t.final.whatsappMessage)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => track("whatsapp_click", { location: "form" })}
                className="flex min-h-11 items-center justify-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground"
              >
                <MessageCircle className="size-4" aria-hidden="true" />
                {f.whatsappAlt}
              </a>
            </form>
          </>
        )}
      </div>
    </div>
  )
}
