"use client"

import { Quote } from "lucide-react"
import { Reveal } from "@/components/ui/reveal"
import { useSite } from "@/components/site-provider"
import { container, h2, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

/**
 * PLACEHOLDER SECTION. Everything here is marked as a placeholder on purpose:
 * replace it with real client stories, quotes and logos (with permission) before launch.
 * Never publish invented testimonials.
 */
export function SocialProof() {
  const { t } = useSite()
  const f = t.proof.featured

  return (
    <section aria-labelledby="proof-title" className={section}>
      <div className={container}>
        <Reveal className="text-center">
          <h2 id="proof-title" className={h2}>{t.proof.h2}</h2>
          <p className="mx-auto mt-3 inline-block rounded-full border border-dashed border-warning bg-warning/10 px-4 py-1.5 text-sm">{t.proof.placeholder}</p>
        </Reveal>

        <Reveal delay={100} className="mt-12 grid gap-8 rounded-3xl bg-brand-ink p-8 text-white md:grid-cols-[2fr_3fr] md:p-12">
          <div>
            <div className="mb-4 size-14 rounded-2xl bg-brand-gradient" aria-hidden="true" />
            <p className="text-sm text-white/70">{f.business}</p>
            <ul className="mt-6 space-y-3">
              {f.results.map((r) => (
                <li key={r} className="text-2xl font-bold">{r}</li>
              ))}
            </ul>
          </div>
          <figure>
            <Quote className="size-8 text-brand-sand" aria-hidden="true" />
            <blockquote className="mt-4 font-serif text-2xl leading-snug md:text-3xl">{f.quote}</blockquote>
            <figcaption className="mt-6 text-sm text-white/80">{f.name}</figcaption>
          </figure>
        </Reveal>

        <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {t.proof.testimonials.map((quote, i) => (
            <Reveal as="li" key={i} delay={i * 100} className={cn("flex flex-col rounded-2xl border border-border bg-card p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-md")}>
              <p className="flex-1 text-lg">“{quote}”</p>
              <p className="mt-6 text-sm text-muted-foreground">{t.proof.testimonialName}</p>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
