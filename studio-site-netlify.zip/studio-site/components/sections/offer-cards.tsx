"use client";

import DisplayCards, { type DisplayCardProps } from "@/components/ui/display-cards";
import { useSite } from "@/components/site-provider";
import { CalendarCheck, Palette, Search } from "lucide-react";

const stacked =
  "[grid-area:stack] before:absolute before:w-[100%] before:outline-1 before:rounded-xl before:outline-border before:h-[100%] before:content-[''] before:bg-blend-overlay before:bg-background/50 grayscale-[100%] hover:before:opacity-0 before:transition-opacity before:duration-700 hover:grayscale-0 before:left-0 before:top-0";

const styles = [
  { icon: Search, iconClassName: "bg-brand-orange", titleClassName: "text-brand-orange", className: `${stacked} hover:-translate-y-10` },
  { icon: Palette, iconClassName: "bg-brand-hibiscus", titleClassName: "text-brand-hibiscus", className: `${stacked} translate-x-12 translate-y-10 hover:-translate-y-1` },
  { icon: CalendarCheck, iconClassName: "bg-brand-atlantic", titleClassName: "text-brand-atlantic", className: "[grid-area:stack] translate-x-24 translate-y-20 hover:translate-y-10" },
];

// The studio's offer, in the order the owner experiences it.
export function OfferCards() {
  const { t } = useSite();

  const cards: DisplayCardProps[] = t.services.cards.map((card, i) => {
    const s = styles[i];
    const Icon = s.icon;
    return {
      icon: <Icon className="size-4 text-white" />,
      title: card.title,
      description: card.description,
      date: card.meta,
      iconClassName: s.iconClassName,
      titleClassName: s.titleClassName,
      className: s.className,
    };
  });

  return (
    <div className="flex min-h-[360px] w-full items-center justify-center overflow-hidden py-16">
      {/* Cards are a fixed 22rem wide and offset to the right, so scale the stack down on phones. */}
      <div className="w-full max-w-3xl origin-center -translate-x-10 scale-[0.7] sm:translate-x-0 sm:scale-100">
        <DisplayCards cards={cards} />
      </div>
    </div>
  );
}
