"use client"

import { useState } from "react"
import { Check, ChevronDown } from "lucide-react"
import { Reveal } from "@/components/ui/reveal"
import { track, useSite } from "@/components/site-provider"
import { formatUSD } from "@/lib/calculator"
import { btn, container, h2, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

export function Pricing() {
  const { t, openForm } = useSite()
  const [installments, setInstallments] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(0)

  const toggle = (next: boolean) => {
    setInstallments(next)
    track("pricing_toggle", { mode: next ? "3_payments" : "full" })
  }

  return (
    <section id="pricing" aria-labelledby="pricing-title" className={cn(section, "scroll-mt-16 bg-muted")}>
      <div className={cn(container, "max-w-[1400px]")}>
        <Reveal className="text-center">
          <h2 id="pricing-title" className={h2}>{t.pricing.h2}</h2>
          <p className="mt-3 text-lg text-muted-foreground">{t.pricing.sub}</p>

          <div role="radiogroup" aria-label={`${t.pricing.payFull} / ${t.pricing.pay3}`} className="mt-8 inline-flex rounded-full border border-border bg-card p-1">
            {[false, true].map((value) => (
              <button
                key={String(value)}
                type="button"
                role="radio"
                aria-checked={installments === value}
                onClick={() => toggle(value)}
                className={cn(
                  "min-h-11 rounded-full px-5 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-lagoon",
                  installments === value ? "bg-brand-ink text-white dark:bg-white dark:text-brand-ink" : "text-muted-foreground",
                )}
              >
                {value ? t.pricing.pay3 : t.pricing.payFull}
              </button>
            ))}
          </div>
        </Reveal>

        <ul className="mx-auto mt-12 grid max-w-[1200px] items-stretch gap-6 lg:grid-cols-3">
          {t.pricing.plans.map((plan, i) => {
            const popular = i === 1
            const amount = installments ? Math.ceil(plan.price / 3) : plan.price
            return (
              <Reveal
                as="li"
                key={plan.name}
                delay={i * 100}
                className={cn(
                  "relative flex min-h-[500px] flex-col rounded-3xl bg-card p-8 shadow-sm transition hover:-translate-y-1 hover:shadow-lg",
                  popular ? "border-[3px] border-brand-hibiscus lg:-translate-y-2 lg:hover:-translate-y-3" : "border border-border",
                )}
              >
                {popular && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-brand-hibiscus to-brand-violet px-4 py-1 text-xs font-semibold text-white">
                    {t.pricing.popular}
                  </span>
                )}
                <h3 className="text-2xl font-semibold">{plan.name}</h3>
                <p className="mt-2 text-muted-foreground">{plan.desc}</p>
                <p className="mt-6 flex items-baseline gap-1">
                  <span key={amount} className="text-5xl font-bold animate-in fade-in-0 slide-in-from-bottom-2 duration-300">{formatUSD(amount)}</span>
                  {installments && <span className="text-sm text-muted-foreground">{t.pricing.perMonth}</span>}
                </p>
                <ul className="mt-8 flex-1 space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex gap-3">
                      <Check className="mt-0.5 size-5 shrink-0 text-brand-lagoon" aria-hidden="true" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button type="button" onClick={() => openForm(`pricing_${i + 1}`)} className={cn(popular ? btn.primary : btn.secondary, "mt-8 w-full")}>
                  {plan.cta}
                </button>
              </Reveal>
            )
          })}
        </ul>

        <p className="mt-10 text-center text-sm font-medium text-muted-foreground">{t.pricing.trust.join(" • ")}</p>

        <div id="faq" className="mx-auto mt-20 max-w-[900px] scroll-mt-24">
          <h3 className="text-center font-serif text-3xl">{t.pricing.faqTitle}</h3>
          <div className="mt-8 divide-y divide-border rounded-2xl border border-border bg-card">
            {t.pricing.faq.map((item, i) => {
              const isOpen = openFaq === i
              const panelId = `faq-panel-${i}`
              return (
                <div key={item.q}>
                  <h4>
                    <button
                      type="button"
                      aria-expanded={isOpen}
                      aria-controls={panelId}
                      onClick={() => {
                        setOpenFaq(isOpen ? null : i)
                        if (!isOpen) track("faq_open", { question: i + 1 })
                      }}
                      className="flex min-h-14 w-full items-center justify-between gap-4 px-6 text-left font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand-lagoon"
                    >
                      {item.q}
                      <ChevronDown className={cn("size-5 shrink-0 transition-transform", isOpen && "rotate-180")} aria-hidden="true" />
                    </button>
                  </h4>
                  <div id={panelId} hidden={!isOpen} className="px-6 pb-5 text-muted-foreground">
                    {item.a}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
