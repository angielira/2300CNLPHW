"use client"

import { Camera, MessageCircle, Music2, Users } from "lucide-react"
import { useSite } from "@/components/site-provider"
import { site, whatsappLink } from "@/lib/site"

export function Footer() {
  const { t } = useSite()
  const year = new Date().getFullYear()

  const columns = [
    { title: t.footer.services, links: t.services.items.map((s) => ({ label: s.title, href: "#services" })) },
    { title: t.footer.company, links: [{ label: t.footer.about, href: "#" }, { label: t.footer.contact, href: `mailto:${site.email}` }] },
    { title: t.footer.legal, links: [{ label: t.footer.privacy, href: "/privacy" }, { label: t.footer.terms, href: "/terms" }] },
  ]

  // Replace "#" with your real profile URLs.
  const socials = [
    { label: "Instagram", href: "#", Icon: Camera },
    { label: "Facebook", href: "#", Icon: Users },
    { label: "TikTok", href: "#", Icon: Music2 },
    { label: "WhatsApp", href: whatsappLink(t.final.whatsappMessage), Icon: MessageCircle },
  ]

  return (
    <footer className="bg-brand-ink px-4 pb-10 pt-20 text-sm text-white/80">
      <div className="mx-auto grid max-w-[1200px] gap-10 sm:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_1fr]">
        <div>
          <p className="flex items-center gap-2 font-serif text-xl text-white">
            <span aria-hidden="true" className="size-8 rounded-full bg-brand-gradient" />
            {site.name}
          </p>
          <p className="mt-3 max-w-xs leading-relaxed">{t.footer.tagline}</p>
          <ul className="mt-5 flex gap-3">
            {socials.map(({ label, href, Icon }) => (
              <li key={label}>
                <a href={href} aria-label={label} target="_blank" rel="noopener noreferrer" className="flex size-11 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/20 hover:text-white">
                  <Icon className="size-5" aria-hidden="true" />
                </a>
              </li>
            ))}
          </ul>
        </div>
        {columns.map((col) => (
          <nav key={col.title} aria-label={col.title}>
            <p className="font-semibold text-white">{col.title}</p>
            <ul className="mt-4 space-y-3">
              {col.links.map((l) => (
                <li key={l.label}>
                  <a href={l.href} className="transition hover:text-brand-sand">{l.label}</a>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>
      <div className="mx-auto mt-14 flex max-w-[1200px] flex-col gap-2 border-t border-white/15 pt-6 text-xs sm:flex-row sm:justify-between">
        <p>{t.footer.area}</p>
        <p>© {year} {site.name}. {t.footer.rights}</p>
      </div>
    </footer>
  )
}
