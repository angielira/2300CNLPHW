"use client"

import { Clock, EyeOff, Shapes } from "lucide-react"
import { Reveal } from "@/components/ui/reveal"
import { useSite } from "@/components/site-provider"
import { container, h2, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

const icons = [Shapes, EyeOff, Clock]

export function Problem() {
  const { t } = useSite()

  return (
    <section aria-labelledby="problem-title" className={cn(section, "bg-muted")}>
      <div className={container}>
        <Reveal className="mx-auto max-w-3xl text-center">
          <h2 id="problem-title" className={h2}>{t.problem.h2}</h2>
          <p className="mt-4 text-lg text-muted-foreground">{t.problem.sub}</p>
        </Reveal>

        <ul className="mt-14 grid gap-6 md:grid-cols-3">
          {t.problem.items.map((item, i) => {
            const Icon = icons[i]
            return (
              <Reveal as="li" key={item.title} delay={i * 100} className="flex flex-col rounded-2xl border border-border bg-card p-8 shadow-sm">
                <Icon className="size-8 text-brand-orange" strokeWidth={2} aria-hidden="true" />
                <h3 className="mt-5 text-[22px] font-semibold leading-snug md:text-2xl">{item.title}</h3>
                <p className="mt-3 text-lg leading-relaxed text-muted-foreground">{item.body}</p>
                <div className="mt-auto pt-8">
                  <p className="text-[40px] font-bold leading-none text-brand-hibiscus md:text-5xl">{item.stat}</p>
                  <p className="mt-2 text-sm">{item.statLabel}</p>
                  <a href={item.href} target="_blank" rel="noopener noreferrer" className="mt-1 inline-block text-xs text-muted-foreground underline-offset-2 hover:underline">
                    {item.source}
                  </a>
                </div>
              </Reveal>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
