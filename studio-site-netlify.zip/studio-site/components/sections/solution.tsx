"use client"

import { Sparkles } from "lucide-react"
import { BeforeAfterSlider } from "@/components/ui/before-after-slider"
import { Reveal } from "@/components/ui/reveal"
import { useSite } from "@/components/site-provider"
import { container, h2, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

// Mock feeds built in CSS — swap for real client screenshots (with permission) when you have them.
const messyTiles = ["#e8d44d", "#9b9b9b", "#d9534f", "#5cb85c", "#f0ad4e", "#7a5c99", "#c9c9c9", "#3a7bd5", "#ff9ec7"]
const messyFonts = ["font-mono", "font-serif italic", "font-sans font-black", "font-mono uppercase", "font-serif", "font-sans"]
const brandTiles = ["bg-brand-orange", "bg-brand-sand", "bg-brand-guava", "bg-brand-hibiscus", "bg-brand-gradient", "bg-brand-violet", "bg-brand-lagoon", "bg-brand-mango", "bg-brand-atlantic"]

function MockFeed({ variant, handle }: { variant: "before" | "after"; handle: string }) {
  const isAfter = variant === "after"
  return (
    <div className={cn("flex h-full w-full flex-col gap-3 p-5", isAfter ? "bg-background" : "bg-[#f3f0e8]")}>
      <div className="flex items-center gap-3">
        <div className={cn("size-14 shrink-0 rounded-full", isAfter ? "bg-brand-gradient ring-4 ring-brand-guava/30" : "bg-[#b5a27a] blur-[1px]")} />
        <div className="min-w-0">
          <p className={cn("truncate text-base", isAfter ? "font-serif text-lg" : "font-mono text-sm")}>{handle}</p>
          <p className={cn("truncate text-xs", isAfter ? "text-muted-foreground" : "font-serif italic text-[#777]")}>
            {isAfter ? "Bakery · Hialeah · Open 7am–7pm" : "pastries!!! call 4 orders 🎂🎂"}
          </p>
        </div>
      </div>
      {isAfter && (
        <div className="flex gap-2">
          {["Menu", "Orders", "Reviews"].map((h) => (
            <span key={h} className="rounded-full border border-brand-hibiscus/40 px-3 py-1 text-[10px] font-medium text-brand-hibiscus">{h}</span>
          ))}
        </div>
      )}
      <div className="grid flex-1 grid-cols-3 gap-1.5">
        {Array.from({ length: 9 }).map((_, i) =>
          isAfter ? (
            <div key={i} className={cn("flex items-end rounded-md p-1.5", brandTiles[i])}>
              <span className="font-serif text-[10px] text-white drop-shadow">{i % 3 === 0 ? "Pastelitos" : ""}</span>
            </div>
          ) : (
            <div key={i} className="flex items-center justify-center overflow-hidden rounded-[2px] p-1" style={{ background: messyTiles[i], transform: `rotate(${(i % 3) - 1}deg)` }}>
              <span className={cn("text-[10px] text-white", messyFonts[i % messyFonts.length])}>{i % 2 ? "SALE" : "new!!"}</span>
            </div>
          ),
        )}
      </div>
    </div>
  )
}

export function Solution() {
  const { t } = useSite()

  return (
    <section aria-labelledby="solution-title" className={section}>
      <div className={cn(container, "grid items-center gap-12 lg:grid-cols-2")}>
        <Reveal className="space-y-5">
          <h2 id="solution-title" className={h2}>{t.solution.h2}</h2>
          {t.solution.paragraphs.map((p) => (
            <p key={p} className="text-lg leading-relaxed text-muted-foreground">{p}</p>
          ))}
          <aside className="flex gap-3 rounded-2xl border-l-4 border-brand-hibiscus bg-muted p-5">
            <Sparkles className="mt-0.5 size-5 shrink-0 text-brand-hibiscus" aria-hidden="true" />
            <p className="font-medium">{t.solution.callout}</p>
          </aside>
        </Reveal>

        <Reveal delay={100} className="scroll-mt-28" >
          <div id="before-after" className="scroll-mt-28">
            <BeforeAfterSlider
              before={<MockFeed variant="before" handle={t.solution.beforeHandle} />}
              after={<MockFeed variant="after" handle={t.solution.afterHandle} />}
              beforeLabel={t.solution.before}
              afterLabel={t.solution.after}
              label={t.solution.sliderLabel}
            />
          </div>
        </Reveal>
      </div>
    </section>
  )
}
