"use client"

import { MessageCircle } from "lucide-react"
import { Reveal } from "@/components/ui/reveal"
import { track, useSite } from "@/components/site-provider"
import { whatsappLink } from "@/lib/site"
import { btn } from "@/lib/styles"
import { cn } from "@/lib/utils"

export function FinalCta() {
  const { t, openForm } = useSite()

  return (
    <section aria-labelledby="final-title" className="relative overflow-hidden bg-brand-gradient px-4 py-24 text-white md:py-[150px]">
      {/* Dark overlay keeps white text above 4.5:1 across the whole gradient */}
      <div aria-hidden="true" className="absolute inset-0 bg-brand-ink/45" />
      <Reveal className="relative mx-auto max-w-[800px] text-center">
        <h2 id="final-title" className="font-serif text-[34px] leading-tight md:text-5xl">{t.final.h2}</h2>
        <p className="mx-auto mt-5 max-w-xl text-lg text-white/90">{t.final.sub}</p>
        <div className="mt-10 flex flex-col justify-center gap-4 sm:flex-row">
          <button type="button" onClick={() => openForm("final_cta")} className={cn(btn.onGradient, "min-h-14 text-lg")}>
            {t.final.cta1}
          </button>
          <a
            href={whatsappLink(t.final.whatsappMessage)}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => track("whatsapp_click", { location: "final_cta" })}
            className={cn(btn.outlineOnGradient, "min-h-14 text-lg")}
          >
            <MessageCircle className="size-5" aria-hidden="true" />
            {t.final.cta2}
          </a>
        </div>
        <p className="mt-6 text-sm text-white/85">{t.final.trust.join(" • ")}</p>
      </Reveal>
    </section>
  )
}
