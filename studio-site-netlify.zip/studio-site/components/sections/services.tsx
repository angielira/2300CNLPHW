"use client"

import { CalendarCheck, Check, ClipboardCheck, Palette, Smartphone, X } from "lucide-react"
import { OfferCards } from "@/components/sections/offer-cards"
import { Reveal } from "@/components/ui/reveal"
import { useSite } from "@/components/site-provider"
import { container, eyebrow, h2, section } from "@/lib/styles"
import { cn } from "@/lib/utils"

const icons = [ClipboardCheck, Palette, Smartphone, CalendarCheck]

/** CSS-built illustrations for each service (no stock photos needed). */
function ServiceVisual({ index }: { index: number }) {
  const frame = "relative aspect-[4/3] w-full overflow-hidden rounded-3xl border border-border bg-muted p-6 shadow-lg"

  if (index === 0)
    return (
      <div className={frame}>
        <div className="mx-auto h-full max-w-xs space-y-3 rounded-2xl bg-card p-5 shadow">
          <p className="font-serif text-lg">Brand check-up</p>
          {[
            [false, "Logo readable on sign"],
            [false, "Consistent colors"],
            [true, "Google profile complete"],
            [false, "Posting every week"],
            [true, "Great product photos"],
          ].map(([ok, label]) => (
            <div key={label as string} className="flex items-center gap-2 text-sm">
              {ok ? <Check className="size-4 text-success" aria-hidden="true" /> : <X className="size-4 text-error" aria-hidden="true" />}
              {label as string}
            </div>
          ))}
        </div>
      </div>
    )

  if (index === 1)
    return (
      <div className={cn(frame, "grid grid-cols-2 gap-4")}>
        <div className="flex items-center justify-center rounded-2xl bg-card shadow">
          <span className="flex size-24 items-center justify-center rounded-full bg-brand-gradient font-serif text-4xl text-white">D</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {["bg-brand-orange", "bg-brand-guava", "bg-brand-violet", "bg-brand-lagoon"].map((c) => (
            <div key={c} className={cn("rounded-xl shadow", c)} />
          ))}
        </div>
        <div className="col-span-2 flex items-end justify-between rounded-2xl bg-card px-5 py-3 shadow">
          <span className="font-serif text-4xl">Aa</span>
          <span className="text-sm text-muted-foreground">DM Serif · Inter</span>
        </div>
      </div>
    )

  if (index === 2)
    return (
      <div className={cn(frame, "flex items-center justify-center")}>
        <div className="h-full w-44 rounded-[2rem] border-4 border-brand-ink bg-card p-3 shadow-xl">
          <div className="mx-auto mb-2 size-10 rounded-full bg-brand-gradient" />
          <div className="mx-auto mb-3 h-2 w-20 rounded bg-foreground/70" />
          <div className="mb-3 flex justify-center gap-1.5">
            {["bg-brand-orange", "bg-brand-guava", "bg-brand-lagoon"].map((c) => (
              <span key={c} className={cn("size-5 rounded-full", c)} />
            ))}
          </div>
          <div className="grid grid-cols-3 gap-1">
            {["bg-brand-sand", "bg-brand-hibiscus", "bg-brand-atlantic", "bg-brand-violet", "bg-brand-mango", "bg-brand-guava"].map((c, i) => (
              <span key={i} className={cn("aspect-square rounded-sm", c)} />
            ))}
          </div>
        </div>
      </div>
    )

  return (
    <div className={frame}>
      <div className="h-full rounded-2xl bg-card p-4 shadow">
        <p className="mb-3 font-serif text-lg">November</p>
        <div className="grid grid-cols-7 gap-1.5">
          {Array.from({ length: 28 }).map((_, i) => {
            const post = [1, 3, 5, 8, 10, 12, 15, 17, 19, 22, 24, 26].includes(i)
            const reel = [5, 12, 19, 26].includes(i)
            return (
              <div key={i} className="flex aspect-square items-center justify-center rounded-md bg-muted text-[10px] text-muted-foreground">
                {reel ? <span className="size-2.5 rounded-full bg-brand-violet" /> : post ? <span className="size-2.5 rounded-full bg-brand-guava" /> : i + 1}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export function Services() {
  const { t } = useSite()

  return (
    <section id="services" aria-labelledby="services-title" className={cn(section, "scroll-mt-16")}>
      <div className={container}>
        <div id="how" className="grid scroll-mt-24 items-center gap-6 lg:grid-cols-2">
          <Reveal>
            <p className={eyebrow}>{t.services.eyebrow}</p>
            <h2 id="services-title" className={cn(h2, "mt-3")}>{t.services.h2}</h2>
            <p className="mt-4 text-lg text-muted-foreground">{t.services.sub}</p>
          </Reveal>
          <OfferCards />
        </div>

        <div className="mt-16 space-y-[100px]">
          {t.services.items.map((item, i) => {
            const Icon = icons[i]
            const flip = i % 2 === 1
            return (
              <div key={item.title} className="grid items-center gap-10 md:grid-cols-2">
                <Reveal className={cn(flip && "md:order-2")}>
                  <Icon className="size-8 text-brand-hibiscus" aria-hidden="true" />
                  <h3 className="mt-4 text-[22px] font-semibold md:text-2xl">{item.title}</h3>
                  <p className="mt-3 text-lg leading-relaxed text-muted-foreground">{item.body}</p>
                  <p className="mt-5 inline-flex rounded-full bg-brand-lagoon/15 px-4 py-1.5 text-sm font-semibold text-brand-ink dark:text-brand-lagoon">
                    {item.callout}
                  </p>
                </Reveal>
                <Reveal delay={100} className={cn(flip && "md:order-1")}>
                  <ServiceVisual index={i} />
                </Reveal>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
