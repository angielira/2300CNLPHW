"use client"

import { createContext, useCallback, useContext, useEffect, useState } from "react"
import { dictionaries, type Dictionary, type Lang } from "@/lib/i18n"
import { CheckupForm } from "@/components/sections/checkup-form"

interface SiteContextValue {
  lang: Lang
  t: Dictionary
  setLang: (lang: Lang) => void
  toggleLang: () => void
  openForm: (source: string) => void
}

const SiteContext = createContext<SiteContextValue | null>(null)

const STORAGE_KEY = "studio-lang"

/** Fires a lightweight analytics event; wire to GA4 or Plausible via window.gtag / window.plausible. */
export function track(event: string, data: Record<string, string | number> = {}) {
  if (typeof window === "undefined") return
  const w = window as unknown as { gtag?: (...a: unknown[]) => void; plausible?: (e: string, o?: unknown) => void }
  w.gtag?.("event", event, data)
  w.plausible?.(event, { props: data })
}

export function SiteProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en")
  const [formOpen, setFormOpen] = useState(false)

  // Restore saved language, otherwise follow the browser (Spanish browsers get Spanish).
  useEffect(() => {
    let saved: string | null = null
    try {
      saved = localStorage.getItem(STORAGE_KEY)
    } catch {}
    if (saved === "en" || saved === "es") setLangState(saved)
    else if (navigator.language?.toLowerCase().startsWith("es")) setLangState("es")
  }, [])

  useEffect(() => {
    document.documentElement.lang = lang
  }, [lang])

  const setLang = useCallback((next: Lang) => {
    setLangState(next)
    try {
      localStorage.setItem(STORAGE_KEY, next)
    } catch {}
    track("language_change", { lang: next })
  }, [])

  const openForm = useCallback((source: string) => {
    track("cta_click", { location: source })
    setFormOpen(true)
  }, [])

  const value: SiteContextValue = {
    lang,
    t: dictionaries[lang],
    setLang,
    toggleLang: () => setLang(lang === "en" ? "es" : "en"),
    openForm,
  }

  return (
    <SiteContext.Provider value={value}>
      {children}
      <CheckupForm open={formOpen} onClose={() => setFormOpen(false)} />
    </SiteContext.Provider>
  )
}

export function useSite() {
  const ctx = useContext(SiteContext)
  if (!ctx) throw new Error("useSite must be used inside <SiteProvider>")
  return ctx
}
